def test_success():
    assert True
